CREATE TABLE IF NOT EXISTS `wonder_storage` (
  `pincode` int(4) DEFAULT NULL,
  `stash` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

