Sv_config = {}

Sv_config.Webhook = "WEBHOOK_HERE"