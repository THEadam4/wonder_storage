Locales["cs"] = {
    ["pin_input_title"] = "Zadej PIN",
    ["pin_input_label"] = "PIN kód",
    ["new_pin_input_title"] = "Zadej nový PIN",
    ["new_pin_input_label"] = "PIN kód",
    ["notify_pin_success"] = "Úspěšně si otevřel sklad!",
    ["notify_wrong_pin"] = "Špatný PIN!",
    ["notify_new_pin_success"] = "Nový PIN: ",
    ["notify_new_pin_error"] = "PIN musí mít 4 číslice!",
}