Locales["en"] = {
    ["pin_input_title"] = "Enter PIN code",
    ["pin_input_label"] = "PIN code",
    ["new_pin_input_title"] = "Enter new PIN code",
    ["new_pin_input_label"] = "PIN code",
    ["notify_pin_success"] = "Successfully opened storage",
    ["notify_wrong_pin"] = "Wrong PIN!",
    ["notify_new_pin_success"] = "New PIN: ",
    ["notify_new_pin_error"] = "PIN code must have 4-digits!",
}