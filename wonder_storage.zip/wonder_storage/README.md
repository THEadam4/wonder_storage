# wonder_storage
 Simple storage script

Dependencies: ox_lib, ox_target, ox_inventory

Insert import.sql in your database.

Made with love <3
